#ifndef DOG_H
#define DOG_H




#include "Mammal.h"
#include <iostream>

using namespace std;

class Dog : public Mammal
{
public: 
	Dog()
	{
		cout << "What is the name of your dog? " << endl;
	}
	void setName(string n)
	{
		name = n;
	}

	void doAction()
	{
		cout << "The dog named" << name << "goes gallop" << endl;
	}

	void speak()
	{
		cout << "The dog named" << name << "says bark! bark!" << endl;
	}
};
#endif
