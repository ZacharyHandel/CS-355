#ifndef MAMMAL_H
#define MAMMAL_H

#include <iostream>

using namespace std; 

class Mammal
{
protected:
	string name; 
	string sound; 
	string aciton; 
public: 
	Mammal()
	{

	}
	Mammal(string n) 
	{
		name = n;
	}
	string getName() const
	{
		return name; 
	}
	virtual void setName() const = 0; 
	virtual void doAction() const = 0; 
	virtual void Speak() const = 0; 
};
#endif